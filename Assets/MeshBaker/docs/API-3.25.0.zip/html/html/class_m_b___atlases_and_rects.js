var class_m_b___atlases_and_rects =
[
    [ "atlases", "class_m_b___atlases_and_rects.html#a995dc6fe932f5ce1043474365834edd4", null ],
    [ "mat2rect_map", "class_m_b___atlases_and_rects.html#a6fc59df6e8c4c8b4ce5ec1a084dffe71", null ],
    [ "texPropertyNames", "class_m_b___atlases_and_rects.html#a3b85079703a6fc5a546e43f6d2a4b393", null ]
];