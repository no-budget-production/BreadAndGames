var dir_e3b7d3ecf224ed13fca771b785f3f0fa =
[
    [ "_testing", "dir_f7fb1bc6aec730aab565b3cb8eb55f3d.html", "dir_f7fb1bc6aec730aab565b3cb8eb55f3d" ],
    [ "core", "dir_ac54348f53d7b34870ddd35fa953ae7e.html", "dir_ac54348f53d7b34870ddd35fa953ae7e" ],
    [ "Editor", "dir_79c5407721e6f8ecf013e10c70298429.html", "dir_79c5407721e6f8ecf013e10c70298429" ],
    [ "TextureBlenders", "dir_439f549794e6eb77247c945314b5d106.html", "dir_439f549794e6eb77247c945314b5d106" ],
    [ "MB2_TextureBakeResults.cs", "_m_b2___texture_bake_results_8cs.html", [
      [ "MB_AtlasesAndRects", "class_m_b___atlases_and_rects.html", "class_m_b___atlases_and_rects" ],
      [ "MB_MultiMaterial", "class_m_b___multi_material.html", "class_m_b___multi_material" ],
      [ "MB_MaterialAndUVRect", "class_m_b___material_and_u_v_rect.html", "class_m_b___material_and_u_v_rect" ],
      [ "MB2_TextureBakeResults", "class_m_b2___texture_bake_results.html", "class_m_b2___texture_bake_results" ],
      [ "Material2AtlasRectangleMapper", "class_m_b2___texture_bake_results_1_1_material2_atlas_rectangle_mapper.html", "class_m_b2___texture_bake_results_1_1_material2_atlas_rectangle_mapper" ]
    ] ],
    [ "MB2_UpdateSkinnedMeshBoundsFromBones.cs", "_m_b2___update_skinned_mesh_bounds_from_bones_8cs.html", [
      [ "MB2_UpdateSkinnedMeshBoundsFromBones", "class_m_b2___update_skinned_mesh_bounds_from_bones.html", null ]
    ] ],
    [ "MB2_UpdateSkinnedMeshBoundsFromBounds.cs", "_m_b2___update_skinned_mesh_bounds_from_bounds_8cs.html", [
      [ "MB2_UpdateSkinnedMeshBoundsFromBounds", "class_m_b2___update_skinned_mesh_bounds_from_bounds.html", "class_m_b2___update_skinned_mesh_bounds_from_bounds" ]
    ] ],
    [ "MB3_BatchPrefabBaker.cs", "_m_b3___batch_prefab_baker_8cs.html", [
      [ "MB3_BatchPrefabBaker", "class_m_b3___batch_prefab_baker.html", "class_m_b3___batch_prefab_baker" ],
      [ "MB3_PrefabBakerRow", "class_m_b3___batch_prefab_baker_1_1_m_b3___prefab_baker_row.html", "class_m_b3___batch_prefab_baker_1_1_m_b3___prefab_baker_row" ]
    ] ],
    [ "MB3_BoneWeightCopier.cs", "_m_b3___bone_weight_copier_8cs.html", [
      [ "MB3_BoneWeightCopier", "class_m_b3___bone_weight_copier.html", "class_m_b3___bone_weight_copier" ]
    ] ],
    [ "MB3_DisableHiddenAnimations.cs", "_m_b3___disable_hidden_animations_8cs.html", [
      [ "MB3_DisableHiddenAnimations", "class_m_b3___disable_hidden_animations.html", "class_m_b3___disable_hidden_animations" ]
    ] ],
    [ "MB3_MBVersionConcrete.cs", "_m_b3___m_b_version_concrete_8cs.html", [
      [ "MBVersionConcrete", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version_concrete.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version_concrete" ]
    ] ],
    [ "MB3_MeshBaker.cs", "_m_b3___mesh_baker_8cs.html", [
      [ "MB3_MeshBaker", "class_m_b3___mesh_baker.html", "class_m_b3___mesh_baker" ]
    ] ],
    [ "MB3_MeshBakerCommon.cs", "_m_b3___mesh_baker_common_8cs.html", [
      [ "MB3_MeshBakerCommon", "class_m_b3___mesh_baker_common.html", "class_m_b3___mesh_baker_common" ]
    ] ],
    [ "MB3_MeshBakerGrouper.cs", "_m_b3___mesh_baker_grouper_8cs.html", [
      [ "MB3_MeshBakerGrouper", "class_m_b3___mesh_baker_grouper.html", "class_m_b3___mesh_baker_grouper" ],
      [ "GrouperData", "class_digital_opus_1_1_m_b_1_1_core_1_1_grouper_data.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_grouper_data" ],
      [ "MB3_MeshBakerGrouperCore", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_baker_grouper_core.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_baker_grouper_core" ],
      [ "MB3_MeshBakerGrouperNone", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_baker_grouper_none.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_baker_grouper_none" ],
      [ "MB3_MeshBakerGrouperGrid", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_baker_grouper_grid.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_baker_grouper_grid" ],
      [ "MB3_MeshBakerGrouperPie", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_baker_grouper_pie.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_baker_grouper_pie" ],
      [ "MB3_MeshBakerGrouperKMeans", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_baker_grouper_k_means.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_baker_grouper_k_means" ],
      [ "MB3_MeshBakerGrouperCluster", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_baker_grouper_cluster.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_baker_grouper_cluster" ]
    ] ],
    [ "MB3_MeshBakerRoot.cs", "_m_b3___mesh_baker_root_8cs.html", [
      [ "MB3_MeshBakerRoot", "class_m_b3___mesh_baker_root.html", "class_m_b3___mesh_baker_root" ],
      [ "ZSortObjects", "class_m_b3___mesh_baker_root_1_1_z_sort_objects.html", "class_m_b3___mesh_baker_root_1_1_z_sort_objects" ],
      [ "Item", "class_m_b3___mesh_baker_root_1_1_z_sort_objects_1_1_item.html", "class_m_b3___mesh_baker_root_1_1_z_sort_objects_1_1_item" ],
      [ "ItemComparer", "class_m_b3___mesh_baker_root_1_1_z_sort_objects_1_1_item_comparer.html", "class_m_b3___mesh_baker_root_1_1_z_sort_objects_1_1_item_comparer" ]
    ] ],
    [ "MB3_MultiMeshBaker.cs", "_m_b3___multi_mesh_baker_8cs.html", [
      [ "MB3_MultiMeshBaker", "class_m_b3___multi_mesh_baker.html", "class_m_b3___multi_mesh_baker" ]
    ] ],
    [ "MB3_TextureBaker.cs", "_m_b3___texture_baker_8cs.html", [
      [ "MB3_TextureBaker", "class_m_b3___texture_baker.html", "class_m_b3___texture_baker" ],
      [ "CreateAtlasesCoroutineResult", "class_m_b3___texture_baker_1_1_create_atlases_coroutine_result.html", "class_m_b3___texture_baker_1_1_create_atlases_coroutine_result" ]
    ] ]
];