var class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_enabled_disabled =
[
    [ "Compare", "class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_enabled_disabled.html#ab6981c1cb51ee6f4443da35e976d4526", null ],
    [ "GetDescription", "class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_enabled_disabled.html#ab47d543c30a45584fbaeae53b8a085dd", null ],
    [ "GetName", "class_digital_opus_1_1_m_b_1_1_core_1_1_group_by_enabled_disabled.html#af10e8d596766106b16e47586b60db05c", null ]
];