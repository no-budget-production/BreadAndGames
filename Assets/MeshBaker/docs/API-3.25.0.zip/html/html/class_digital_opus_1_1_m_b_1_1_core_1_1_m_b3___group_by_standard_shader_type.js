var class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___group_by_standard_shader_type =
[
    [ "Compare", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___group_by_standard_shader_type.html#addee64700804803043a250fa1d2bc5be", null ],
    [ "GetDescription", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___group_by_standard_shader_type.html#a3302a9a4a4be10405aa57932a5757ede", null ],
    [ "GetName", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___group_by_standard_shader_type.html#acee5f7520b80f11b7853066c0820122b", null ]
];