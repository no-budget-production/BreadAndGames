var class_m_b3___test_bake_all_with_same_material =
[
    [ "listOfObjsToCombineBad", "class_m_b3___test_bake_all_with_same_material.html#a57678cb7f3549cae95deea5e098282bb", null ],
    [ "listOfObjsToCombineGood", "class_m_b3___test_bake_all_with_same_material.html#a55d4486b66381125eaeaab1776aa8d28", null ]
];