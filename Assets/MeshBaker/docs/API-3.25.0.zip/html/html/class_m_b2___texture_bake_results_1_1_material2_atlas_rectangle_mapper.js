var class_m_b2___texture_bake_results_1_1_material2_atlas_rectangle_mapper =
[
    [ "Material2AtlasRectangleMapper", "class_m_b2___texture_bake_results_1_1_material2_atlas_rectangle_mapper.html#adb27bdf4518047f6f1ae4f8b84ae7f5a", null ],
    [ "TryMapMaterialToUVRect", "class_m_b2___texture_bake_results_1_1_material2_atlas_rectangle_mapper.html#a6a98041aa8d8bbbbd9ff2725c42e48b4", null ]
];