var class_digital_opus_1_1_m_b_1_1_core_1_1_atlas_packing_result =
[
    [ "AtlasPackingResult", "class_digital_opus_1_1_m_b_1_1_core_1_1_atlas_packing_result.html#a8d010d7133efdd3861c1163c17ad328e", null ],
    [ "CalcUsedWidthAndHeight", "class_digital_opus_1_1_m_b_1_1_core_1_1_atlas_packing_result.html#ac2e0f93896dd2afbf89216f256d7c1ec", null ],
    [ "ToString", "class_digital_opus_1_1_m_b_1_1_core_1_1_atlas_packing_result.html#a4e307b1cbc0e1d69675c09a60a4885d8", null ],
    [ "atlasX", "class_digital_opus_1_1_m_b_1_1_core_1_1_atlas_packing_result.html#af8c5f930dd33dfffe931c312197add2c", null ],
    [ "atlasY", "class_digital_opus_1_1_m_b_1_1_core_1_1_atlas_packing_result.html#a11696cfae77a1755212e072c9c2d9aca", null ],
    [ "data", "class_digital_opus_1_1_m_b_1_1_core_1_1_atlas_packing_result.html#a6f895195343cf4ec6e05f95e2601cd4f", null ],
    [ "padding", "class_digital_opus_1_1_m_b_1_1_core_1_1_atlas_packing_result.html#a36f6350880d0bc47fb6dd8c933778984", null ],
    [ "rects", "class_digital_opus_1_1_m_b_1_1_core_1_1_atlas_packing_result.html#a361f001f1a9d163b932542497ba843b9", null ],
    [ "srcImgIdxs", "class_digital_opus_1_1_m_b_1_1_core_1_1_atlas_packing_result.html#adbdaeba21a61b603e231c2f1e3db0928", null ],
    [ "usedH", "class_digital_opus_1_1_m_b_1_1_core_1_1_atlas_packing_result.html#a710802edcd259b106ad1be74b588fd0b", null ],
    [ "usedW", "class_digital_opus_1_1_m_b_1_1_core_1_1_atlas_packing_result.html#ab13193d5c4de015227e170020f92ac1b", null ]
];