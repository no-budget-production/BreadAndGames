var class_digital_opus_1_1_m_b_1_1_core_1_1_procedural_material_info =
[
    [ "originalIsReadableVal", "class_digital_opus_1_1_m_b_1_1_core_1_1_procedural_material_info.html#a30cd640dac6749ed583d729bbe3fd3ef", null ],
    [ "proceduralMat", "class_digital_opus_1_1_m_b_1_1_core_1_1_procedural_material_info.html#a4777fdcc17efb0db8dab8235fe199592", null ]
];