var class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___texture_packer =
[
    [ "CeilToNearestPowerOfTwo", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___texture_packer.html#ad967bba94dfdd14485ef0b3fc0ae3d20", null ],
    [ "GetRects", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___texture_packer.html#a150381e0f6ca6a16a7f831bd4af0652e", null ],
    [ "GetRects", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___texture_packer.html#a536b9ec7b6e5970d249b06573362fef5", null ],
    [ "normalizeRects", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___texture_packer.html#a07e645e992f0fb2e80bb8e66c855a6c0", null ],
    [ "RoundToNearestPositivePowerOfTwo", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___texture_packer.html#a5ddcac54d27258077dc34fecf883cda4", null ],
    [ "atlasMustBePowerOfTwo", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___texture_packer.html#a943159927cc028d4cfa59a44427122c8", null ],
    [ "LOG_LEVEL", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___texture_packer.html#a126c6af8e9e2c25b4086fdee242f2a25", null ]
];