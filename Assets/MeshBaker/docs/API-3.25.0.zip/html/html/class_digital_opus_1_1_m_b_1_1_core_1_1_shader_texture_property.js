var class_digital_opus_1_1_m_b_1_1_core_1_1_shader_texture_property =
[
    [ "ShaderTextureProperty", "class_digital_opus_1_1_m_b_1_1_core_1_1_shader_texture_property.html#aab705e3c94a0333266f1214a0807871b", null ],
    [ "GetNames", "class_digital_opus_1_1_m_b_1_1_core_1_1_shader_texture_property.html#a4ba1ec53c5bd3e955da9fa616819211d", null ],
    [ "isNormalMap", "class_digital_opus_1_1_m_b_1_1_core_1_1_shader_texture_property.html#a644f41deb23e1feda44528ff90593138", null ],
    [ "name", "class_digital_opus_1_1_m_b_1_1_core_1_1_shader_texture_property.html#af90b475b3710d77617cd57b82f9346d0", null ]
];