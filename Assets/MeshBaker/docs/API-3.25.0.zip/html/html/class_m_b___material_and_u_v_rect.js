var class_m_b___material_and_u_v_rect =
[
    [ "MB_MaterialAndUVRect", "class_m_b___material_and_u_v_rect.html#a2153120025164857dfdc88f56ea3a46a", null ],
    [ "Equals", "class_m_b___material_and_u_v_rect.html#af06bf65d69edfc0f85e586ae337e437c", null ],
    [ "GetHashCode", "class_m_b___material_and_u_v_rect.html#a016d0081bae5af9fb64144cf81fb961c", null ],
    [ "atlasRect", "class_m_b___material_and_u_v_rect.html#aa3f06f01a8141e1a7ccf5edb59d35038", null ],
    [ "material", "class_m_b___material_and_u_v_rect.html#a027b8a37a920a707e914bd0741aa0c46", null ],
    [ "samplingEncapsulatinRect", "class_m_b___material_and_u_v_rect.html#a59ebf5724544138f27db7a6ebacdc077", null ],
    [ "samplingRectMatAndUVTiling", "class_m_b___material_and_u_v_rect.html#a8d15686b62d29141aaaf5ae7c4b70c3a", null ],
    [ "sourceMaterialTiling", "class_m_b___material_and_u_v_rect.html#af4bbdca060e252890ed892465ac08eaa", null ],
    [ "srcObjName", "class_m_b___material_and_u_v_rect.html#ae8fe97f4b25b102329c425bc03226f04", null ]
];