var _m_b2___core_8cs =
[
    [ "MB2_EditorMethodsInterface", "interface_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___editor_methods_interface.html", "interface_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___editor_methods_interface" ],
    [ "MB2_LightmapOptions", "_m_b2___core_8cs.html#a7c6398a07657fe2d755d25429858086c", [
      [ "preserve_current_lightmapping", "_m_b2___core_8cs.html#a7c6398a07657fe2d755d25429858086ca493573de4d5e57f230f3061abdc012f2", null ],
      [ "ignore_UV2", "_m_b2___core_8cs.html#a7c6398a07657fe2d755d25429858086ca1cb645e4e8ea47b147319ade082fdbde", null ],
      [ "copy_UV2_unchanged", "_m_b2___core_8cs.html#a7c6398a07657fe2d755d25429858086cad6467bb91f2b5b37697f13261bbd3dd6", null ],
      [ "generate_new_UV2_layout", "_m_b2___core_8cs.html#a7c6398a07657fe2d755d25429858086caf0e5280529f04e7f8c2244f35d15ff7d", null ],
      [ "copy_UV2_unchanged_to_separate_rects", "_m_b2___core_8cs.html#a7c6398a07657fe2d755d25429858086caa8a8a9f8f6a4ef9823722a222c8f71d5", null ]
    ] ],
    [ "MB2_OutputOptions", "_m_b2___core_8cs.html#a4372895ec4a7b2979289d4c94f237b56", [
      [ "bakeIntoSceneObject", "_m_b2___core_8cs.html#a4372895ec4a7b2979289d4c94f237b56ac832ad25feee259fb38c90ba2efcb2c1", null ],
      [ "bakeMeshAssetsInPlace", "_m_b2___core_8cs.html#a4372895ec4a7b2979289d4c94f237b56a7df18698c5a370e08979202e0e2d59a6", null ],
      [ "bakeIntoPrefab", "_m_b2___core_8cs.html#a4372895ec4a7b2979289d4c94f237b56a9be03fd048c42f0690396cc836276139", null ]
    ] ],
    [ "MB2_PackingAlgorithmEnum", "_m_b2___core_8cs.html#a5d11f2c3865d5dbc29bfd97b9e78104b", [
      [ "UnitysPackTextures", "_m_b2___core_8cs.html#a5d11f2c3865d5dbc29bfd97b9e78104babba03e7f51c9acc85f4c78586db7686b", null ],
      [ "MeshBakerTexturePacker", "_m_b2___core_8cs.html#a5d11f2c3865d5dbc29bfd97b9e78104ba23d585267a303e11b4f8075fc357e6db", null ],
      [ "MeshBakerTexturePacker_Fast", "_m_b2___core_8cs.html#a5d11f2c3865d5dbc29bfd97b9e78104ba60e589da2a2d168e72aebac5f16da7ee", null ],
      [ "MeshBakerTexturePacker_Horizontal", "_m_b2___core_8cs.html#a5d11f2c3865d5dbc29bfd97b9e78104ba294d829a2980176dddcc148f47a280c2", null ],
      [ "MeshBakerTexturePacker_Vertical", "_m_b2___core_8cs.html#a5d11f2c3865d5dbc29bfd97b9e78104ba6347cdd129a6d417d58fb3a469b72cc5", null ]
    ] ],
    [ "MB2_ValidationLevel", "_m_b2___core_8cs.html#a9412ea8d3114e6a024a115e96b67d38c", [
      [ "none", "_m_b2___core_8cs.html#a9412ea8d3114e6a024a115e96b67d38ca334c4a4c42fdb79d7ebc3e73b517e6f8", null ],
      [ "quick", "_m_b2___core_8cs.html#a9412ea8d3114e6a024a115e96b67d38ca1df3746a4728276afdc24f828186f73a", null ],
      [ "robust", "_m_b2___core_8cs.html#a9412ea8d3114e6a024a115e96b67d38ca00bd624b5b21d2b07edf398c1ce98b5e", null ]
    ] ],
    [ "MB_ObjsToCombineTypes", "_m_b2___core_8cs.html#a5ba05a8353f1a501abcfc71c15ce0a0a", [
      [ "prefabOnly", "_m_b2___core_8cs.html#a5ba05a8353f1a501abcfc71c15ce0a0aad69e089f38b1dc0ca132a4c696d268cb", null ],
      [ "sceneObjOnly", "_m_b2___core_8cs.html#a5ba05a8353f1a501abcfc71c15ce0a0aa680d35dd4a19fa769e10789f2e29ae58", null ],
      [ "dontCare", "_m_b2___core_8cs.html#a5ba05a8353f1a501abcfc71c15ce0a0aa32b30f7725eda783b4664a07ea2c93b7", null ]
    ] ],
    [ "MB_OutputOptions", "_m_b2___core_8cs.html#a5d3897d924035aac447ac1da4756f135", [
      [ "bakeIntoPrefab", "_m_b2___core_8cs.html#a5d3897d924035aac447ac1da4756f135a9be03fd048c42f0690396cc836276139", null ],
      [ "bakeMeshsInPlace", "_m_b2___core_8cs.html#a5d3897d924035aac447ac1da4756f135a38abbcc433242489254095a7ef6965d7", null ],
      [ "bakeTextureAtlasesOnly", "_m_b2___core_8cs.html#a5d3897d924035aac447ac1da4756f135a6d6360db9a2413b78e75b9b173142a9a", null ],
      [ "bakeIntoSceneObject", "_m_b2___core_8cs.html#a5d3897d924035aac447ac1da4756f135ac832ad25feee259fb38c90ba2efcb2c1", null ]
    ] ],
    [ "MB_RenderType", "_m_b2___core_8cs.html#a114b08d0ac271ab7811ee092e6758496", [
      [ "meshRenderer", "_m_b2___core_8cs.html#a114b08d0ac271ab7811ee092e6758496ac0da20e91a681374aaa954a0313d61f6", null ],
      [ "skinnedMeshRenderer", "_m_b2___core_8cs.html#a114b08d0ac271ab7811ee092e6758496a88b5cc0d3db93db6fbfa7d85c4aedc1d", null ]
    ] ],
    [ "ProgressUpdateCancelableDelegate", "_m_b2___core_8cs.html#ada61496df2badb1b9bae80dc5013278f", null ],
    [ "ProgressUpdateDelegate", "_m_b2___core_8cs.html#a010baff935764e19e32134ce62295921", null ]
];