var class_m_b3___batch_prefab_baker =
[
    [ "MB3_PrefabBakerRow", "class_m_b3___batch_prefab_baker_1_1_m_b3___prefab_baker_row.html", "class_m_b3___batch_prefab_baker_1_1_m_b3___prefab_baker_row" ],
    [ "outputPrefabFolder", "class_m_b3___batch_prefab_baker.html#a4d20796a3ff83483dac9b0a6e29761d2", null ],
    [ "prefabRows", "class_m_b3___batch_prefab_baker.html#a19170eca2f12f278301896e506fae6f6", null ]
];