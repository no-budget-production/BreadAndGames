var dir_ac54348f53d7b34870ddd35fa953ae7e =
[
    [ "TextureCombiner", "dir_8f71c4e78b9f0353cd3ab2ab7fcbe9bf.html", "dir_8f71c4e78b9f0353cd3ab2ab7fcbe9bf" ],
    [ "MB2_Core.cs", "_m_b2___core_8cs.html", "_m_b2___core_8cs" ],
    [ "MB2_Log.cs", "_m_b2___log_8cs.html", "_m_b2___log_8cs" ],
    [ "MB2_MBVersion.cs", "_m_b2___m_b_version_8cs.html", [
      [ "MBVersionInterface", "interface_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version_interface.html", "interface_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version_interface" ],
      [ "MBVersion", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b_version" ]
    ] ],
    [ "MB3_AgglomerativeClustering.cs", "_m_b3___agglomerative_clustering_8cs.html", [
      [ "MB3_AgglomerativeClustering", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___agglomerative_clustering.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___agglomerative_clustering" ],
      [ "ClusterNode", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___agglomerative_clustering_1_1_cluster_node.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___agglomerative_clustering_1_1_cluster_node" ],
      [ "item_s", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___agglomerative_clustering_1_1item__s.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___agglomerative_clustering_1_1item__s" ],
      [ "ClusterDistance", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___agglomerative_clustering_1_1_cluster_distance.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___agglomerative_clustering_1_1_cluster_distance" ]
    ] ],
    [ "MB3_CopyBoneWeights.cs", "_m_b3___copy_bone_weights_8cs.html", [
      [ "MB3_CopyBoneWeights", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___copy_bone_weights.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___copy_bone_weights" ]
    ] ],
    [ "MB3_GrouperCluster.cs", "_m_b3___grouper_cluster_8cs.html", [
      [ "MB3_KMeansClustering", "class_m_b3___k_means_clustering.html", "class_m_b3___k_means_clustering" ]
    ] ],
    [ "MB3_MeshCombiner.cs", "_m_b3___mesh_combiner_8cs.html", [
      [ "MB3_MeshCombiner", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner" ],
      [ "MBBlendShapeKey", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner_1_1_m_b_blend_shape_key.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner_1_1_m_b_blend_shape_key" ],
      [ "MBBlendShapeValue", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner_1_1_m_b_blend_shape_value.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner_1_1_m_b_blend_shape_value" ]
    ] ],
    [ "MB3_MeshCombinerSimple.cs", "_m_b3___mesh_combiner_simple_8cs.html", [
      [ "MB3_MeshCombinerSingle", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner_single.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner_single" ],
      [ "SerializableIntArray", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner_single_1_1_serializable_int_array.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner_single_1_1_serializable_int_array" ],
      [ "MB_DynamicGameObject", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner_single_1_1_m_b___dynamic_game_object.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner_single_1_1_m_b___dynamic_game_object" ],
      [ "MeshChannels", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner_single_1_1_mesh_channels.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner_single_1_1_mesh_channels" ],
      [ "MBBlendShapeFrame", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner_single_1_1_m_b_blend_shape_frame.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner_single_1_1_m_b_blend_shape_frame" ],
      [ "MBBlendShape", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner_single_1_1_m_b_blend_shape.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner_single_1_1_m_b_blend_shape" ],
      [ "MeshChannelsCache", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner_single_1_1_mesh_channels_cache.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner_single_1_1_mesh_channels_cache" ],
      [ "BoneAndBindpose", "struct_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner_single_1_1_bone_and_bindpose.html", "struct_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___mesh_combiner_single_1_1_bone_and_bindpose" ]
    ] ],
    [ "MB3_MultiMeshCombiner.cs", "_m_b3___multi_mesh_combiner_8cs.html", [
      [ "MB3_MultiMeshCombiner", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___multi_mesh_combiner.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___multi_mesh_combiner" ],
      [ "CombinedMesh", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___multi_mesh_combiner_1_1_combined_mesh.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___multi_mesh_combiner_1_1_combined_mesh" ]
    ] ],
    [ "MB3_PriorityQueue.cs", "_m_b3___priority_queue_8cs.html", [
      [ "PriorityQueue< TPriority, TValue >", "class_digital_opus_1_1_m_b_1_1_core_1_1_priority_queue_3_01_t_priority_00_01_t_value_01_4.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_priority_queue_3_01_t_priority_00_01_t_value_01_4" ]
    ] ],
    [ "MB3_UVTransform.cs", "_m_b3___u_v_transform_8cs.html", [
      [ "DVector2", "struct_digital_opus_1_1_m_b_1_1_core_1_1_d_vector2.html", "struct_digital_opus_1_1_m_b_1_1_core_1_1_d_vector2" ],
      [ "DRect", "struct_digital_opus_1_1_m_b_1_1_core_1_1_d_rect.html", "struct_digital_opus_1_1_m_b_1_1_core_1_1_d_rect" ],
      [ "MB3_UVTransformUtility", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___u_v_transform_utility.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___u_v_transform_utility" ]
    ] ],
    [ "MB_TGAWriter.cs", "_m_b___t_g_a_writer_8cs.html", [
      [ "MB_TGAWriter", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b___t_g_a_writer.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b___t_g_a_writer" ]
    ] ],
    [ "MB_Utility.cs", "_m_b___utility_8cs.html", [
      [ "MB_Utility", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b___utility.html", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b___utility" ],
      [ "MeshAnalysisResult", "struct_digital_opus_1_1_m_b_1_1_core_1_1_m_b___utility_1_1_mesh_analysis_result.html", "struct_digital_opus_1_1_m_b_1_1_core_1_1_m_b___utility_1_1_mesh_analysis_result" ]
    ] ]
];