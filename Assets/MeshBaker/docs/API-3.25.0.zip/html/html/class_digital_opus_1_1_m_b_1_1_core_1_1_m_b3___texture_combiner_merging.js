var class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_merging =
[
    [ "MB3_TextureCombinerMerging", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_merging.html#a294e153b703b4b5ea51e982af780f8c6", null ],
    [ "BuildTransformMeshUV2AtlasRectB", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_merging.html#a2ecc2507bc0c9337b5b1c62d07b98981", null ],
    [ "DoIntegrityCheckMergedEncapsulatingSamplingRects", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_merging.html#a18a7d6ad4cc1717962b0ddc5b6974d28", null ],
    [ "MergeOverlappingDistinctMaterialTexturesAndCalcMaterialSubrects", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_merging.html#aa95f95d71d3cc1c2c87af9176dc23727", null ],
    [ "LOG_LEVEL", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner_merging.html#a1e7238a4f9a21d16920c7a058a3d8642", null ]
];