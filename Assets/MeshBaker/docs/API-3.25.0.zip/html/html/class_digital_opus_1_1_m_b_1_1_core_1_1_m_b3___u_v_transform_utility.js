var class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___u_v_transform_utility =
[
    [ "CombineTransforms", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___u_v_transform_utility.html#a3ba5e5c0d330f5842fd9325703cb7ea4", null ],
    [ "CombineTransforms", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___u_v_transform_utility.html#a4d7f5562222bc76f4b297f12056a7ba5", null ],
    [ "GetEncapsulatingRect", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___u_v_transform_utility.html#a267334f89c842aac7df9e6159f70cd82", null ],
    [ "GetEncapsulatingRectShifted", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___u_v_transform_utility.html#acd3beed9d2ce03fced6ed137d38b945a", null ],
    [ "GetShiftTransformToFitBinA", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___u_v_transform_utility.html#aadc12a0e5124571f4f8d7fa8c5d0e126", null ],
    [ "InverseTransform", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___u_v_transform_utility.html#ab893d6b328928bd8e383eb3a27e0ee87", null ],
    [ "RectContains", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___u_v_transform_utility.html#a6de18bc2057f64b5016d8873eede9217", null ],
    [ "RectContains", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___u_v_transform_utility.html#ab9ab3d1c74f9c6eaf1b39724a6e17371", null ],
    [ "RectContainsShifted", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___u_v_transform_utility.html#ac4694e9f4209dfe4121005f2ed71fb8d", null ],
    [ "RectContainsShifted", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___u_v_transform_utility.html#a54c03ac1bf786b71aec330a1da1fd0a4", null ],
    [ "Test", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___u_v_transform_utility.html#adc1ff4853703ded78a92ee6fa50a3310", null ],
    [ "TransformPoint", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___u_v_transform_utility.html#aecbc5718ae2b3a6145e64efaa8d1980c", null ],
    [ "TransformPoint", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___u_v_transform_utility.html#a3d3d5b2f35796e967bed5b211c19c650", null ],
    [ "TransformX", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___u_v_transform_utility.html#a50d97064dccb0f722b289c9b3e0153d3", null ]
];