var class_m_b3___bone_weight_copier_editor =
[
    [ "CopyBoneWeightsFromSeamMeshToOtherMeshes", "class_m_b3___bone_weight_copier_editor.html#a7e0f0d200519b1e97c18c1b90d2c0d68", null ],
    [ "CreateNewMeshBaker", "class_m_b3___bone_weight_copier_editor.html#aad99b18dc527e31f145fae411fb69aa3", null ],
    [ "OnInspectorGUI", "class_m_b3___bone_weight_copier_editor.html#a5c6b9ff507b69dcb70fab66fed472dd7", null ],
    [ "SaveMeshesToOutputFolderAndAssignToSMRs", "class_m_b3___bone_weight_copier_editor.html#a1e3f18b5239ef1bf2eea1147190315b9", null ]
];