var class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_baker_editor_internal_1_1_multi_mat_submesh_info =
[
    [ "MultiMatSubmeshInfo", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_baker_editor_internal_1_1_multi_mat_submesh_info.html#a900a35b4b050a2bd32ee6f88cda99045", null ],
    [ "Equals", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_baker_editor_internal_1_1_multi_mat_submesh_info.html#a573b9b74133b38d78548d820e8341845", null ],
    [ "GetHashCode", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_baker_editor_internal_1_1_multi_mat_submesh_info.html#a26406636607dfb39777b545b8ea74b92", null ],
    [ "shader", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_baker_editor_internal_1_1_multi_mat_submesh_info.html#a8b4ea0fe06a0155cb191b3636048adde", null ],
    [ "stdBlendMode", "class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_baker_editor_internal_1_1_multi_mat_submesh_info.html#a0f8c724c539184ea21c1ee2f789721df", null ]
];